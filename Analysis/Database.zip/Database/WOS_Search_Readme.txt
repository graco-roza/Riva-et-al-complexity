Towards a cohesive understanding of ecological complexity

Web of Science trial search (23 Sept 2021, Helsinki)

----------------------------

Search 1: TI = "ecolog* complex*"  OR AK = "ecolog* complex*"

[188 hits]

Search 2: TI = "complex system science" OR TI = "complex system theory" OR AK = "complex system science" OR AK = "complex system theory"

[42 hits]

Search 3: WC = "Ecology" NOT TI = "ecolog* complex*" NOT AK = "ecolog* complex*" NOT TI = "complex system science" NOT TI = "complex system theory" NOT AK = "complex system science" NOT AK = "complex system theory"

[Random selection of articles to match the hits of Search 1]